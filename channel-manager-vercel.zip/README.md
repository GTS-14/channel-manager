# Channel Manager Lite — Vercel + Postgres
Prêt à déployer sur Vercel. Build = `prisma generate` + `prisma migrate deploy` + `next build`.

**Déploiement iPhone :**
1) Vercel → New Project → Upload → ce `.zip`.
2) Accepte **Vercel Postgres** (DATABASE_URL auto).
3) Deploy → ouvre l’URL.

Pages : **/calendar**, **/finance**, **/inbox** (MVP).
