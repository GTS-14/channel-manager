import Link from 'next/link';
export default function Page() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Calendrier unique</h2>
        <p>Importe les URLs iCal (Airbnb / Booking / VRBO) et vois tout au même endroit.</p>
        <Link className="btn" href="/calendar">Ouvrir le calendrier</Link>
      </div>
      <div className="card">
        <h2>Finances</h2>
        <p>Importe un CSV pour calculer le CA total et par plateforme.</p>
        <Link className="btn" href="/finance">Ouvrir les finances</Link>
      </div>
      <div className="card">
        <h2>Messagerie</h2>
        <p>Centralise tes messages et génère des brouillons avec IA.</p>
        <Link className="btn" href="/inbox">Ouvrir la messagerie</Link>
      </div>
    </div>
  );
}
