'use client';
import Papa from 'papaparse';
import { useState } from 'react';
type Row = { platform: string; date: string; gross: number; fees: number; net: number; currency: string };
export default function FinancePage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [stats, setStats] = useState<{ totalNet: number; byPlatform: Record<string, number> } | null>(null);
  function handleFile(file: File) {
    Papa.parse(file, {
      header: true,
      complete: (res) => {
        const parsed: Row[] = (res.data as any[])
          .map(r => ({
            platform: (r.platform || r.Platform || r.source || '').toUpperCase(),
            date: r.date || r.Date || r.payout_date,
            gross: Number(r.gross || r.Gross || r.amount || 0),
            fees: Number(r.fees || r.Fees || r.commission || 0),
            net: Number(r.net || r.Net || r.paid_amount || 0),
            currency: r.currency || r.Currency || 'EUR',
          }))
          .filter(r => r.date && !Number.isNaN(r.net));
        setRows(parsed);
      }
    });
  }
  async function save() {
    const res = await fetch('/api/payouts', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ rows })});
    if (res.ok) {
      const kpi = await (await fetch('/api/kpis')).json();
      setStats(kpi);
      alert('Import enregistré.');
    } else {
      alert('Erreur de sauvegarde');
    }
  }
  return (
    <div className="grid">
      <div className="card">
        <h3>Importer un CSV (payouts/transactions)</h3>
        <input type="file" accept=".csv,text/csv" onChange={(e)=> e.target.files && handleFile(e.target.files[0])} />
        <button className="btn" onClick={save} disabled={!rows.length} style={{marginTop:10}}>Enregistrer</button>
      </div>
      <div className="card">
        <h3>Aperçu</h3>
        <table className="table">
          <thead><tr><th>Plateforme</th><th>Date</th><th>Net</th><th>Devise</th></tr></thead>
          <tbody>
            {rows.slice(0,50).map((r,i)=>(
              <tr key={i}><td>{r.platform}</td><td>{r.date}</td><td>{r.net.toFixed(2)}</td><td>{r.currency}</td></tr>
            ))}
          </tbody>
        </table>
        {rows.length>50 && <p>... {rows.length-50} lignes supplémentaires</p>}
      </div>
      <div className="card" style={{gridColumn:'1 / -1'}}>
        <h3>KPIs</h3>
        {stats ? (
          <>
            <p><strong>Total net:</strong> {(stats.totalNet/100).toFixed(2)} €</p>
            <ul>
              {Object.entries(stats.byPlatform).map(([p, v]) => <li key={p}><span className="badge">{p}</span> {(v/100).toFixed(2)} €</li>)}
            </ul>
          </>
        ) : <p>Importe puis enregistre un CSV pour voir les KPIs.</p>}
      </div>
    </div>
  );
}
