import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { parseIcs } from '@/lib/ics';
import { Platform } from '@prisma/client';
export const dynamic = 'force-dynamic';
export async function POST(_req: NextRequest) {
  const urls = await prisma.icalUrl.findMany({ include: { listing: true } });
  let count = 0;
  for (const u of urls) {
    try {
      const events = await parseIcs(u.url);
      for (const ev of events) {
        await prisma.reservation.upsert({
          where: { id: `${u.listingId}_${ev.start.toISOString()}_${ev.end.toISOString()}_${u.id}` },
          update: {},
          create: {
            id: `${u.listingId}_${ev.start.toISOString()}_${ev.end.toISOString()}_${u.id}`,
            listingId: u.listingId,
            start: ev.start, end: ev.end,
            source: u.source ?? Platform.MANUAL,
            externalId: ev.uid, guestName: ev.summary,
          }
        });
        count++;
      }
    } catch (e) {
      console.error('Failed to parse', u.url, e);
    }
  }
  return NextResponse.json({ imported: count });
}
