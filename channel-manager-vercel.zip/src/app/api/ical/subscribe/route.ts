import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { Platform } from '@prisma/client';
export async function POST(req: NextRequest) {
  const { listingName, platform, url } = await req.json();
  if (!listingName || !url) return new NextResponse('Missing fields', { status: 400 });
  const account = await prisma.account.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: { email: 'demo@example.com' },
  });
  const existing = await prisma.listing.findFirst({ where: { name: listingName, accountId: account.id } });
  const listing = existing ?? await prisma.listing.create({ data: { name: listingName, accountId: account.id, platform: Platform.MANUAL } });
  await prisma.icalUrl.create({ data: { listingId: listing.id, url, source: (Platform as any)[platform] || Platform.MANUAL } });
  return NextResponse.json({ ok: true });
}
