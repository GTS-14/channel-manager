import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { Platform } from '@prisma/client';
export async function POST(req: NextRequest) {
  const { rows } = await req.json();
  const account = await prisma.account.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: { email: 'demo@example.com' },
  });
  const data = (rows as any[]).map(r => ({
    accountId: account.id,
    platform: (Platform as any)[(r.platform || 'MANUAL').toUpperCase()] ?? Platform.MANUAL,
    date: new Date(r.date),
    grossCents: Math.round(Number(r.gross || r.net) * 100),
    feesCents: Math.round(Number(r.fees || 0) * 100),
    netCents: Math.round(Number(r.net || r.gross || 0) * 100),
    currency: r.currency || 'EUR',
  }));
  await prisma.payout.createMany({ data, skipDuplicates: true });
  return NextResponse.json({ ok: true, count: data.length });
}
