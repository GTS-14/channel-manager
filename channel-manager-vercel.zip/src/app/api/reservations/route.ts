import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
export const dynamic = 'force-dynamic';
export async function GET() {
  const res = await prisma.reservation.findMany({ include: { listing: true } });
  const events = res.map(r => ({
    id: r.id,
    title: `${r.listing.name} • ${r.guestName ?? 'Réservé'}`,
    start: r.start.toISOString(),
    end: r.end.toISOString(),
  }));
  return NextResponse.json({ events });
}
