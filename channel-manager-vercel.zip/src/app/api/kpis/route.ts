import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
export const dynamic = 'force-dynamic';
export async function GET() {
  const payouts = await prisma.payout.findMany();
  const totalNet = payouts.reduce((acc, p) => acc + p.netCents, 0);
  const byPlatform: Record<string, number> = {};
  for (const p of payouts) {
    byPlatform[p.platform] = (byPlatform[p.platform] || 0) + p.netCents;
  }
  return NextResponse.json({ totalNet, byPlatform });
}
