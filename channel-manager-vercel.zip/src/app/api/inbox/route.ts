import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
export const dynamic = 'force-dynamic';
export async function GET() {
  const account = await prisma.account.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: { email: 'demo@example.com' },
  });
  const messages = await prisma.message.findMany({
    where: { accountId: account.id },
    orderBy: { timestamp: 'desc' },
  });
  return NextResponse.json({ messages });
}
export async function POST(req: NextRequest) {
  const { body } = await req.json();
  const account = await prisma.account.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: { email: 'demo@example.com' },
  });
  const msg = await prisma.message.create({ data: { accountId: account.id, threadId: 'demo', body } });
  return NextResponse.json({ message: msg });
}
