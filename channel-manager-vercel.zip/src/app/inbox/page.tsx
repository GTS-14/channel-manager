'use client';
import { useEffect, useState } from 'react';
type Msg = { id: string; threadId: string; subject?: string; body: string; timestamp: string };
export default function InboxPage() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [draft, setDraft] = useState('');
  async function load() {
    const res = await fetch('/api/inbox');
    const data = await res.json();
    setMsgs(data.messages);
  }
  useEffect(() => { load(); }, []);
  async function suggestReply(m: Msg) {
    const res = await fetch('/api/ai/reply', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ message: m }) });
    const data = await res.json();
    setDraft(data.reply);
  }
  return (
    <div className="grid">
      <div className="card">
        <h3>Ajouter un message (MVP)</h3>
        <form onSubmit={async (e)=>{
          e.preventDefault();
          const body = (e.currentTarget.elements.namedItem('body') as HTMLTextAreaElement).value;
          await fetch('/api/inbox', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ body })});
          (e.currentTarget.elements.namedItem('body') as HTMLTextAreaElement).value = '';
          load();
        }}>
          <textarea name="body" className="input" placeholder="Colle ici un message reçu (MVP)..." rows={5} required/>
          <button className="btn" type="submit" style={{marginTop:10}}>Ajouter</button>
        </form>
      </div>
      <div className="card">
        <h3>Conversations</h3>
        {msgs.length === 0 && <p>Aucun message pour l'instant.</p>}
        <ul>
          {msgs.map(m => (
            <li key={m.id} style={{marginBottom:12}}>
              <div style={{fontSize:'.9rem', color:'#555'}}>{new Date(m.timestamp).toLocaleString()}</div>
              <div style={{whiteSpace:'pre-wrap'}}>{m.body}</div>
              <button className="btn" onClick={()=>suggestReply(m)} style={{marginTop:8}}>Proposer une réponse (IA)</button>
            </li>
          ))}
        </ul>
      </div>
      <div className="card" style={{gridColumn:'1 / -1'}}>
        <h3>Brouillon proposé</h3>
        <textarea className="input" rows={8} value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Clique sur un message pour générer un brouillon..." />
      </div>
    </div>
  );
}
